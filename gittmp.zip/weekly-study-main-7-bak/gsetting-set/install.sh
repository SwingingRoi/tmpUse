#!/bin/bash
cp com.example.myapp.gschema.xml /usr/share/glib-2.0/schemas/
glib-compile-schemas /usr/share/glib-2.0/schemas/
gsettings set com.example.myapp getinfotime 3
gsettings get com.example.myapp getinfotime
