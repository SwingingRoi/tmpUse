#include "NetworkMonitor.h"
#include <QFile>
#include <QTextStream>
#include <QThread>
#include <QDebug>

NetworkMonitor::NetworkMonitor(const QString& interfaceName)
    : m_interfaceName(interfaceName) {}

QString NetworkMonitor::getDownloadSpeed() {
    // 获取初始接收字节数
    long initialBytes = getReceivedBytes();
    if (initialBytes == -1) {
        return "Error: Failed to get initial bytes.";
    }

    // 等待 0.1 秒
    QThread::msleep(100);

    // 获取下一次接收字节数
    long finalBytes = getReceivedBytes();
    if (finalBytes == -1) {
        return "Error: Failed to get final bytes.";
    }

    // 计算下载的字节数
    long bytesDownloaded = finalBytes - initialBytes;

    // 转换为 KB/s，返回以 KB/s 为单位的下载速度，保留 3 位小数
    double speedKBps = (bytesDownloaded / 1024.0) * 10;  // 10倍放大
    return QString::number(speedKBps, 'f', 3);  // 返回下载速度的 QString
}

long NetworkMonitor::getReceivedBytes() {
    QFile file("/proc/net/dev");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Failed to open /proc/net/dev";
        return -1;
    }

    QTextStream in(&file);
    QString line;
    //line = in.readLine();
    do {
        line = in.readLine();
        // 查找包含指定接口名的行
        if (line.contains(m_interfaceName)) {
            // 提取接收字节数
            QStringList fields = line.split(QRegExp("\\s+"), QString::SkipEmptyParts);
            if (fields.size() >= 3) {
                bool ok;
                long bytes = fields[1].toLong(&ok);
                if (ok) {
                    return bytes;
                }
            }
            break;
        }
    } while (!in.atEnd());

    return -1;  // 返回 -1 表示失败
}

