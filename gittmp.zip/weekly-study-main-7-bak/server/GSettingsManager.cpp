#include "GSettingsManager.h"
#include <QDebug>

GSettingsManager::GSettingsManager(const QString &schemaId, const QString &key, QObject *parent)
    : QObject(parent), m_schemaId(schemaId), m_key(key)
{
    // 检查 schema 是否存在
    if (!QGSettings::isSchemaInstalled(m_schemaId.toUtf8())) {
        qCritical() << "GSettings schema" << m_schemaId << "is not installed.";
        return;
    }

    // 创建 QGSettings 对象
    m_settings = new QGSettings(m_schemaId.toUtf8(), QByteArray(), this);

    // 连接信号槽以监听变化
    connect(m_settings, &QGSettings::changed, this, &GSettingsManager::onSettingChanged);

    // 初始化时读取当前值
    QVariant currentValue = m_settings->get(m_key);
    qDebug() << "Initial value of" << m_key << ":" << currentValue.toInt();
}

QVariant GSettingsManager::getGSettingsValue() const
{
    // 获取 GSettings 值时检查是否有效
    QVariant value = m_settings->get(m_key);
    if (!value.isValid()) {
        qWarning() << "Invalid value for key" << m_key;
    }
    return value;
}

void GSettingsManager::setGSettingsValue(const QVariant &value)
{
    m_settings->set(m_key, value);
    qDebug() << "Set new value for" << m_key << ":" << value.toInt();
}

void GSettingsManager::startListeningForChanges()
{
    // 启动监听
    qDebug() << "Listening for changes to" << m_key;
}

void GSettingsManager::onSettingChanged(const QString &key)
{
    if (key == m_key) {
        QVariant newValue = m_settings->get(key);
        qDebug() << "Value of" << key << "changed to:" << newValue.toInt();
    }
}

