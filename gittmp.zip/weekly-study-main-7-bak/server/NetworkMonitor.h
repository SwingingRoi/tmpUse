#ifndef NETWORKMONITOR_H
#define NETWORKMONITOR_H

#include <QString>

class NetworkMonitor
{
public:
    // 构造函数，指定监控的网络接口名称
    explicit NetworkMonitor(const QString& interfaceName);

    // 获取下载速度，返回单位为 KB/s，保留 3 位小数的字符串
    QString getDownloadSpeed();

private:
    // 网络接口名称
    QString m_interfaceName;

    // 从 /proc/net/dev 中获取接收字节数
    long getReceivedBytes();
};

#endif // NETWORKMONITOR_H

