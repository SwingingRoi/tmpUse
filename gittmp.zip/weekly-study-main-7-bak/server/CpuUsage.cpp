#include "CpuUsage.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <unistd.h>

// 构造函数，初始化所有成员变量为 "0"
CpuUsage::CpuUsage()
    : user("0"), nice("0"), system("0"), idle("0"), iowait("0"), irq("0"),
      softirq("0"), steal("0"), guest("0"), guest_nice("0") {}

// 从 /proc/stat 读取并解析 CPU 使用情况
bool CpuUsage::readFromProcStat() {
    QFile file("/proc/stat");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open /proc/stat!";
        return false;
    }

    QTextStream in(&file);
    QString line = in.readLine();
    file.close();

    QStringList parts = line.split(" ", QString::SkipEmptyParts);
    if (parts.size() >= 10) {
        user = parts[1];
        nice = parts[2];
        system = parts[3];
        idle = parts[4];
        iowait = parts[5];
        irq = parts[6];
        softirq = parts[7];
        steal = parts[8];
        guest = parts[9];
        guest_nice = parts[10];
        return true;
    }
    return false;
}

// 计算 CPU 占用率，基于前后两次的 CPU 时间差，处理 QString 数据
double CpuUsage::calculateUsage(const CpuUsage &prevUsage) const {
    long prev_idle = prevUsage.idle.toLong() + prevUsage.iowait.toLong();
    long curr_idle = idle.toLong() + iowait.toLong();

    long prev_non_idle = prevUsage.user.toLong() + prevUsage.nice.toLong() +
                          prevUsage.system.toLong() + prevUsage.irq.toLong() +
                          prevUsage.softirq.toLong() + prevUsage.steal.toLong();
    long curr_non_idle = user.toLong() + nice.toLong() + system.toLong() +
                          irq.toLong() + softirq.toLong() + steal.toLong();

    long prev_total = prev_idle + prev_non_idle;
    long curr_total = curr_idle + curr_non_idle;

    long total_diff = curr_total - prev_total;
    long idle_diff = curr_idle - prev_idle;

    return (1.0 - static_cast<double>(idle_diff) / total_diff) * 100.0;
}

// 获取 CPU 占用率并返回字符串表示
QString CpuUsage::getCpuUsage() {
    CpuUsage prevUsage;
    if (!prevUsage.readFromProcStat()) {
        return "Failed to read CPU usage data!";
    }

    // 等待 1 秒钟来计算 CPU 使用率的变化
    sleep(1);

    CpuUsage currUsage;
    if (!currUsage.readFromProcStat()) {
        return "Failed to read current CPU usage data!";
    }

    double usage = currUsage.calculateUsage(prevUsage);
    return QString::number(usage, 'f', 2);
}

