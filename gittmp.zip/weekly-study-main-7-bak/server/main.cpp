#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusError>
#include <QDBusMessage>
#include <QDBusConnectionInterface>
#include <QDebug>
//#include <QTextStream>
//#include <QTimer>
#include "cpuinfoservice.h"
#include "GSettingsManager.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // D-Bus 服务注册部分
    CpuInfoService cpuInfoService;
    if (!QDBusConnection::sessionBus().registerService("com.example.SystemInfo")) {
        qFatal("Failed to register D-Bus service: %s", qPrintable(QDBusConnection::sessionBus().lastError().message()));
        return 1;
    }

    if (!QDBusConnection::sessionBus().registerObject("/SystemInfo", &cpuInfoService, QDBusConnection::ExportAllSlots)) {
        qFatal("Failed to register D-Bus object: %s", qPrintable(QDBusConnection::sessionBus().lastError().message()));
        return 1;
    }
#if 0
    // GSettings 管理部分
    const QString schemaId = "com.example.myapp";  // 定义的 schema ID
    const QString key = "getinfotime";             // 定义的键

    // 创建 GSettingsManager 对象
    GSettingsManager manager(schemaId, key);

    // 读取当前值
    QVariant currentValue = manager.getGSettingsValue();
    qDebug() << "Current value of" << key << ":" << currentValue.toInt();

    // 修改 GSettings 键值
    //manager.setGSettingsValue(10);  // 设置新值为 10

    // 开始监听键值变化
    manager.startListeningForChanges();
    
    /*
    // 定时器，每隔一段时间检查是否有新的输入
    QTimer timer;
    QObject::connect(&timer, &QTimer::timeout, [&]() {
        // 每次定时器超时时，检查是否有新的输入
        QTextStream stream(stdin);
        qDebug() << "Enter a new value for 'getinfotime' (or type 'exit' to quit):";
        QString input = stream.readLine();

        if (input == "exit") {
            qDebug() << "Exiting program.";
            a.quit();
        } else {
            bool ok;
            int newValue = input.toInt(&ok);
            if (ok) {
                // 设置新的 GSettings 值
                manager.setGSettingsValue(newValue);
                // 输出当前值
                QVariant updatedValue = manager.getGSettingsValue();
                qDebug() << "Updated value of" << key << ":" << updatedValue.toInt();
            } else {
                qDebug() << "Invalid input. Please enter a valid number.";
            }
        }
    });
    timer.start(1000);  // 每 1 秒钟检查一次用户输入
    */
#endif

    // 启动事件循环，保持服务和监听持续运行
    return a.exec();
}

