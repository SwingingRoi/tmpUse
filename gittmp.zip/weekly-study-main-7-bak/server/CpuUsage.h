#ifndef CPUUSAGE_H
#define CPUUSAGE_H

#include <QString>

class CpuUsage
{
public:
    CpuUsage();  // 构造函数，初始化成员变量
    bool readFromProcStat();  // 从 /proc/stat 读取 CPU 使用情况
    QString getCpuUsage();  // 获取 CPU 占用率并返回字符串

private:
    QString user;
    QString nice;
    QString system;
    QString idle;
    QString iowait;
    QString irq;
    QString softirq;
    QString steal;
    QString guest;
    QString guest_nice;

    double calculateUsage(const CpuUsage &prevUsage) const;  // 计算 CPU 占用率
};

#endif // CPUUSAGE_H

