#include <QCoreApplication>  
#include <QDBusConnection>  
#include <QDBusInterface>  
#include <QDBusReply>  
#include <QVariantMap>  
#include <QDebug>  
  
int main(int argc, char *argv[])  
{  
    QCoreApplication a(argc, argv);  
  
    QDBusConnection bus = QDBusConnection::sessionBus();  
  
    // 检查是否连接到D-Bus  
    if (!bus.isConnected()) {  
        qFatal("Cannot connect to the D-Bus session bus.");  
        return -1;  
    }  
  
    // 创建D-Bus接口对象  
    QDBusInterface cpuInfoInterface("com.example.CpuInfoService", "/CpuInfo", "com.example.CpuInfoService", bus);  
  
    // 检查接口是否有效  
    if (!cpuInfoInterface.isValid()) {  
        qFatal("Cannot find the D-Bus interface.");  
        return -1;  
    }  
  
    // 调用getCpu方法  
    QDBusReply<QVariantMap> cpuReply = cpuInfoInterface.call("getCpu");  
    if (cpuReply.isValid() && cpuReply.value().contains("result")) {  
        double cpuUsage = cpuReply.value().value("result").toDouble();  
        qDebug() << "CPU Usage:" << cpuUsage << "%";  
    } else {  
        qWarning() << "Failed to get CPU usage:" << cpuReply.error().message();  
    }  
  
    // 调用getDownload方法  
    QDBusReply<QVariantMap> downloadReply = cpuInfoInterface.call("getDownload");  
    if (downloadReply.isValid() && downloadReply.value().contains("result")) {  
        double downloadSpeed = downloadReply.value().value("result").toDouble();  
        qDebug() << "Download Speed:" << downloadSpeed << "Mbps or whatever unit your script uses";  
    } else {  
        qWarning() << "Failed to get download speed:" << downloadReply.error().message();  
    }  
  
    return a.exec(); // 实际上，在这个例子中，这行代码是有用的，因为它会保持应用程序运行直到接收到退出信号  
}
