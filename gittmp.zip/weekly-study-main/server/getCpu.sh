#!/bin/bash  
 
#export LANG=en_US.UTF-8

export LANGUAGE=en_US.UTF8

# 获取 CPU 使用率  
cpu_usage=$(mpstat 1 1 | awk '/Average/ {print 100 - $NF}')  
  
# 打印 CPU 使用率  
echo $cpu_usage
