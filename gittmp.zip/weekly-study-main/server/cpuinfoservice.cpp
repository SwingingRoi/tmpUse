// cpuinfoservice.cpp  
#include "cpuinfoservice.h"  
#include <QDebug>  
  
CpuInfoService::CpuInfoService(QObject *parent)  
    : QObject(parent),  
      m_cpuUsage("0"),  
      m_downloadSpeed("0")  
{
    int defaultTime =3000;
    QProcess process;
    process.start("gsettings get com.example.myapp getinfotime");
    process.waitForFinished();
    QString output(process.readAllStandardOutput());
    output = output.replace("\n", "");
    if(output == "3" || output == "5" || output == "10"){
    	defaultTime = output.toInt() * 1000;
    }
    //qDebug()<<QString(defaultTime);
    updateInfo();
    connect(&m_timer, &QTimer::timeout, this, &CpuInfoService::updateInfo);  
    m_timer.start(defaultTime); // 每3秒更新一次信息
}  
  
CpuInfoService::~CpuInfoService()  
{  
    m_timer.stop();  
}  
  
QString CpuInfoService::cpuUsage() const  
{  
    return m_cpuUsage;  
}  
  
QString  CpuInfoService::downloadSpeed() const  
{  
    return m_downloadSpeed;  
}  
  
QString CpuInfoService::getCpu() const  
{  
    return cpuUsage();  
}  
  
QString CpuInfoService::getDownload() const  
{  
    return downloadSpeed();  
}  
  
void CpuInfoService::updateInfo()  
{  
    QProcess process;
    process.start("./getCpu.sh");
    process.waitForFinished();
    QString output1(process.readAllStandardOutput());
    m_cpuUsage = output1.remove('%').replace("\n","");
    qDebug() <<output1;

    QString netCard = "eth0";
    process.start("./getDownloadSpeed.sh "+netCard);
    process.waitForFinished();
    QString output2(process.readAllStandardOutput().replace("\n",""));
    qDebug() <<output2;
    m_downloadSpeed = output2;
}

