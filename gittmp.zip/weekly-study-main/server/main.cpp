// main.cpp  
#include <QCoreApplication>  
#include "cpuinfoservice.h"  
#include <QDBusInterface>
#include <QDBusReply>
#include <QDebug>
#include <iostream>


int main(int argc, char *argv[])  
{  

    QCoreApplication a(argc, argv);  
    if (!QDBusConnection::sessionBus().isConnected()) {
	    qFatal("Cannot connect to the D-Bus session bus.");
	    return 1;
    }
    //"com.example.CpuInfoService", "/CpuInfo", "com.example.CpuInfoServiceInterface"
    if (!QDBusConnection::sessionBus().registerService("com.example.MyService")) {
	    qFatal("Cannot register service on D-Bus.");
	    return 1;
    }
    CpuInfoService cpuInfoService;
    QDBusConnection::sessionBus().registerObject("/MyObject", &cpuInfoService, QDBusConnection::ExportAllSlots); 
    return a.exec();  
}
