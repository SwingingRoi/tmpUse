#!/bin/bash
export SUDO_GID=1000
export DISPLAY=:0
export COLORTERM=truecolor
export USERNAME=root
export SUDO_COMMAND=/bin/su
export XDG_SESSION_ID=3
export USER=root
export PWD=/home/yq/Desktop/weekly-study-main
export HOME=/root
export SUDO_USER=yq
export SUDO_UID=1000
export MAIL=/var/mail/root
export SHELL=/bin/bash
export TERM=xterm-256color
export SHLVL=1
export LOGNAME=root
export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/0/bus
export XDG_RUNTIME_DIR=/run/user/0
export XAUTHORITY=/run/user/1000/gdm/Xauthority
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin
export LESSOPEN=| /usr/bin/lesspipe %s
export OLDPWD=/home/yq/Desktop
cd /home/yq/Desktop/weekly-study-main/
/home/yq/Desktop/weekly-study-main/FloatingBall
