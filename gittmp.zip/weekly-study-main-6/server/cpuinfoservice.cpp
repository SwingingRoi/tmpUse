// cpuinfoservice.cpp  
#include "cpuinfoservice.h"  
#include <QDebug>  
  
CpuInfoService::CpuInfoService(QObject *parent)  
    : QObject(parent),  
      m_cpuUsage("0"),  
      m_downloadSpeed("0")  
{
//    connect(&m_timer, &QTimer::timeout, this, &CpuInfoService::updateInfo);  
//    m_timer.start(3000); // 每3秒更新一次信息  
}  
  
CpuInfoService::~CpuInfoService()  
{  
  //  m_timer.stop();  
}  
  
QString CpuInfoService::cpuUsage() const  
{  
    return m_cpuUsage;  
}  
  
QString  CpuInfoService::downloadSpeed() const  
{  
    return m_downloadSpeed;  
}  
  
QString CpuInfoService::getCpu()  
{
    updateInfo();   	
    return cpuUsage();  
}  
  
QString CpuInfoService::getDownload()  
{  
    updateInfo();
    return downloadSpeed();  
}  
  
void CpuInfoService::updateInfo()  
{  
    QProcess process;
    process.start("./getCpu.sh");
    process.waitForFinished();
    QString output1(process.readAllStandardOutput());
    m_cpuUsage = output1.remove('%').replace("\n", "");

    qDebug() <<output1;

    QString netCard = "eth0";
    process.start("./getDownloadSpeed.sh "+netCard);
    process.waitForFinished();
    QString output2(process.readAllStandardOutput());
    qDebug() <<output2;
    m_downloadSpeed = output2.replace("\n", "");
}

