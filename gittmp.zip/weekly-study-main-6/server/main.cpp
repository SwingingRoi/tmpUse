// main.cpp  
#include "cpuinfoservice.h"  
#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusError>
#include <QDBusMessage>
#include <QDBusConnectionInterface>  

int main(int argc, char *argv[])  
{  
    QCoreApplication a(argc, argv);  
    CpuInfoService cpuInfoService;  
    if (!QDBusConnection::sessionBus().registerService("com.example.SystemInfo")) {
	qFatal("Failed to register D-Bus service: %s", qPrintable(QDBusConnection::sessionBus().lastError().message()));
	return 1;
    }
    
    if (!QDBusConnection::sessionBus().registerObject("/SystemInfo", &cpuInfoService,QDBusConnection::ExportAllSlots)) {
	qFatal("Failed to register D-Bus object: %s", qPrintable(QDBusConnection::sessionBus().lastError().message()));
	return 1;
    }  
    return a.exec();  
}
