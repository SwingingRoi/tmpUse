// cpuinfoservice.h  
#ifndef CPUINFOSERVICE_H  
#define CPUINFOSERVICE_H  
  
#include <QObject>  
#include <QDBusConnection>  
#include <QTimer>  
#include <QProcess>  
#include <QDebug>
#include <QString>
#include <QCoreApplication>
#include <QDBusConnectionInterface>
#include <QDBusError>
#include <QDebug>
#include <QDBusAbstractAdaptor>
class CpuInfoService : public QObject  
{  
    Q_OBJECT  
     	Q_CLASSINFO("D-Bus Interface","com.example.SystemInfo")
public:  
    explicit CpuInfoService(QObject *parent = nullptr);  
    ~CpuInfoService();  
  
    QString cpuUsage() const;  
    QString  downloadSpeed() const;  
  
public slots:  
    QString getCpu();  
    QString getDownload();  
  
private slots:  
    void updateInfo(); 
  
private:  
    QString m_cpuUsage;  
    QString m_downloadSpeed;  
    //QTimer m_timer;  
};  
  
#endif // CPUINFOSERVICE_H
