#ifndef GSETTINGS_MANAGER_H
#define GSETTINGS_MANAGER_H

#include <QObject>
#include <QGSettings>
#include <QString>

class GSettingsManager : public QObject
{
    Q_OBJECT

public:
    explicit GSettingsManager(const QString &schemaId, const QString &key, QObject *parent = nullptr);
   
    // 读取 GSettings 键值
    QVariant getGSettingsValue() const;

    QGSettings *m_settings = nullptr;

private:
    QString m_schemaId;
    QString m_key;
};

#endif // GSETTINGS_MANAGER_H

