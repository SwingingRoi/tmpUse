#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusError>
#include <QDBusMessage>
#include <QDBusConnectionInterface>
#include <QDebug>
#include "cpuinfoservice.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    // D-Bus 服务注册部分
    CpuInfoService cpuInfoService;
    if (!QDBusConnection::sessionBus().registerService("com.example.SystemInfo")) {
        qFatal("Failed to register D-Bus service: %s", qPrintable(QDBusConnection::sessionBus().lastError().message()));
        return 1;
    }

    if (!QDBusConnection::sessionBus().registerObject("/SystemInfo", &cpuInfoService, QDBusConnection::ExportAllSlots)) {
        qFatal("Failed to register D-Bus object: %s", qPrintable(QDBusConnection::sessionBus().lastError().message()));
        return 1;
    }

    // 启动事件循环，保持服务和监听持续运行
    return a.exec();
}

