// cpuinfoservice.cpp  
#include "cpuinfoservice.h" 
#include "CpuUsage.h"
#include "NetworkMonitor.h"
#include <QDebug>  
  
CpuInfoService::CpuInfoService(QObject *parent)  
    : QObject(parent),  
      m_cpuUsage("0"),  
      m_downloadSpeed("0")  
{
}  
  
CpuInfoService::~CpuInfoService()  
{  
}  
  
QString CpuInfoService::cpuUsage() const  
{  
    return m_cpuUsage;  
}  
  
QString  CpuInfoService::downloadSpeed() const  
{  
    return m_downloadSpeed;  
}  
  
QString CpuInfoService::getCpu()  
{
    updateInfo();   	
    return cpuUsage();  
}  
  
QString CpuInfoService::getDownload()  
{  
    updateInfo();
    return downloadSpeed();  
}

void CpuInfoService::updateInfo()
{
    CpuUsage cpuUsage;
    m_cpuUsage = cpuUsage.getCpuUsage();
    qDebug() << "CPU Usage is " << m_cpuUsage;
    
    NetworkMonitor monitor("eth0");
    m_downloadSpeed = monitor.getDownloadSpeed();
    qDebug() << "Download Speed is " << m_downloadSpeed << "KB/s";
}
